
import React from 'react';
import type { ShortIdea } from '../types';
import { DownloadIcon, FilmIcon } from './icons';

interface ShortCardProps {
  short: ShortIdea;
}

const ShortCard: React.FC<ShortCardProps> = ({ short }) => {
  const handleDownload = () => {
    const content = `Title: ${short.title}\n\nDescription: ${short.description}\n\nVisual Concept: ${short.visualConcept}`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    const safeTitle = short.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    link.download = `short_idea_${safeTitle || 'untitled'}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  };

  return (
    <div className="bg-gray-800 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300">
      <div className="relative">
        <img 
          src={short.thumbnailUrl} 
          alt={short.title} 
          className="w-full h-40 object-cover" 
          onError={(e) => (e.currentTarget.src = 'https://picsum.photos/seed/error/300/160')} // Fallback image
        />
        <div className="absolute top-2 right-2 bg-black bg-opacity-50 p-1 rounded-full">
          <FilmIcon className="w-5 h-5 text-purple-400" />
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-lg font-semibold text-purple-300 mb-2 truncate" title={short.title}>
          {short.title}
        </h3>
        <p className="text-sm text-gray-400 mb-3 h-20 overflow-y-auto" title={short.description}>
          {short.description}
        </p>
        <div className="mb-4">
            <p className="text-xs font-medium text-gray-500 mb-1">Visual Concept:</p>
            <p className="text-sm text-gray-300 h-12 overflow-y-auto" title={short.visualConcept}>
                {short.visualConcept}
            </p>
        </div>
        <button
          onClick={handleDownload}
          className="w-full flex items-center justify-center mt-3 px-4 py-2 border border-purple-500 text-sm font-medium rounded-md text-purple-300 hover:bg-purple-500 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500 transition-colors duration-150"
        >
          <DownloadIcon className="w-4 h-4 mr-2" />
          Download Info
        </button>
      </div>
    </div>
  );
};

export default ShortCard;
    