
import React from 'react';

export const YouTubeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 28 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M27.3445 3.08431C27.0139 1.86685 26.0135 0.866471 24.7953 0.536601C22.6246 0 14.0002 0 14.0002 0C14.0002 0 5.37584 0 3.20512 0.536601C1.98687 0.866471 0.986501 1.86685 0.655871 3.08431C0.000732422 5.27283 0.000732422 10.0001 0.000732422 10.0001C0.000732422 10.0001 0.000732422 14.7274 0.655871 16.9159C0.986501 18.1334 1.98687 19.1338 3.20512 19.4636C5.37584 20.0002 14.0002 20.0002 14.0002 20.0002C14.0002 20.0002 22.6246 20.0002 24.7953 19.4636C26.0135 19.1338 27.0139 18.1334 27.3445 16.9159C28.0004 14.7274 28.0004 10.0001 28.0004 10.0001C28.0004 10.0001 27.9997 5.27283 27.3445 3.08431Z" />
    <path d="M11.1992 14.2858L18.4844 10.0001L11.1992 5.71436V14.2858Z" fill="white"/>
  </svg>
);

export const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12L17 6.75l-1.25 5.25a4.5 4.5 0 01-3.09 3.09L7.5 16.5l5.25 1.25a4.5 4.5 0 013.09 3.09L17 21.25l1.25-5.25a4.5 4.5 0 013.09-3.09L22.5 12l-5.25-1.25a4.5 4.5 0 01-3.09-3.09L18.25 12z" />
  </svg>
);

export const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
  </svg>
);

export const FilmIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 20.25h12m-7.5-3.75V17.25m4.5 0V17.25m-8.25 0V12.75m4.5 0V12.75m-4.5 0H4.5m15 0H19.5M4.5 6.75H2.25m2.25 0V4.5m0 2.25H6.75m-2.25 0H2.25m15 0H17.25m2.25 0V4.5m0 2.25H21.75m-2.25 0h2.25M4.5 11.25H2.25m2.25 0V9m0 2.25H6.75m-2.25 0H2.25m15 0H17.25m2.25 0V9m0 2.25H21.75m-2.25 0h2.25m-15 3.75H2.25m2.25 0v2.25m0-2.25H6.75m-2.25 0H2.25m15 0H17.25m2.25 0v2.25m0-2.25H21.75m-2.25 0h2.25M12 17.25V4.5m0 12.75a3 3 0 01-3-3H9a3 3 0 01-3 3v0a3 3 0 013-3h6a3 3 0 013 3v0a3 3 0 01-3 3h0a3 3 0 01-3-3z" />
  </svg>
);
    