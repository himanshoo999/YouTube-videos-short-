
import React, { useState } from 'react';
import { YouTubeIcon, SparklesIcon } from './icons';

interface YouTubeInputFormProps {
  onSubmit: (url: string) => void;
  isLoading: boolean;
}

const YouTubeInputForm: React.FC<YouTubeInputFormProps> = ({ onSubmit, isLoading }) => {
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!youtubeUrl.trim()) {
      setError('Please enter a YouTube video URL.');
      return;
    }
    // Basic regex for YouTube URL validation (not exhaustive)
    const youtubeRegex = /^(https|http):\/\/(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[\w-]{11}(&\S*)?$/;
    if (!youtubeRegex.test(youtubeUrl)) {
      setError('Please enter a valid YouTube video URL (e.g., https://www.youtube.com/watch?v=dQw4w9WgXcQ).');
      return;
    }
    setError('');
    onSubmit(youtubeUrl);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-xl mx-auto bg-gray-800 p-6 sm:p-8 rounded-xl shadow-2xl space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-center text-purple-400 mb-6">
        Generate YouTube Shorts Ideas
      </h2>
      <div>
        <label htmlFor="youtubeUrl" className="block text-sm font-medium text-gray-300 mb-1">
          YouTube Video Link
        </label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <YouTubeIcon className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="url"
            name="youtubeUrl"
            id="youtubeUrl"
            className="focus:ring-purple-500 focus:border-purple-500 block w-full pl-10 pr-3 py-3 sm:text-sm border-gray-600 bg-gray-700 text-gray-100 rounded-md placeholder-gray-400"
            placeholder="e.g., https://www.youtube.com/watch?v=yourvideo"
            value={youtubeUrl}
            onChange={(e) => {
              setYoutubeUrl(e.target.value);
              if (error) setError(''); // Clear error on new input
            }}
            aria-describedby="youtube-url-error"
            disabled={isLoading}
          />
        </div>
        {error && <p className="mt-2 text-sm text-red-400" id="youtube-url-error">{error}</p>}
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="w-full flex items-center justify-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors duration-150"
      >
        {isLoading ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Generating...
          </>
        ) : (
          <>
            <SparklesIcon className="w-5 h-5 mr-2" />
            Generate Ideas
          </>
        )}
      </button>
       <p className="text-xs text-gray-500 text-center pt-2">
        Make sure the <code>API_KEY</code> environment variable is set for Gemini.
      </p>
    </form>
  );
};

export default YouTubeInputForm;
    