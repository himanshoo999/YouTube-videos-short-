
import React from 'react';
import type { ShortIdea } from '../types';
import ShortCard from './ShortCard';

interface ShortsDisplayProps {
  shorts: ShortIdea[];
}

const ShortsDisplay: React.FC<ShortsDisplayProps> = ({ shorts }) => {
  if (shorts.length === 0) {
    return (
      <div className="text-center text-gray-500 py-8">
        <p>No short ideas generated yet. Enter a YouTube URL above to start!</p>
      </div>
    );
  }

  return (
    <div className="mt-10">
      <h2 className="text-2xl font-semibold text-purple-400 mb-6 text-center">Generated Short Ideas</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 xl:gap-8">
        {shorts.map((short) => (
          <ShortCard key={short.id} short={short} />
        ))}
      </div>
    </div>
  );
};

export default ShortsDisplay;
    