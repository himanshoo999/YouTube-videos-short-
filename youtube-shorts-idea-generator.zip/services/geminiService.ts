
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { GeminiResponseShort } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY for Gemini is not set. Please ensure the process.env.API_KEY environment variable is configured.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "FALLBACK_KEY_IF_YOU_MUST_BUT_WARN" }); // Fallback only for type-checking, real key needed at runtime

// Model for text generation
const TEXT_MODEL_NAME = "gemini-2.5-flash-preview-04-17";

export const generateShortsIdeas = async (youtubeUrl: string): Promise<GeminiResponseShort[]> => {
  if (!API_KEY) {
    throw new Error("Gemini API key is not configured. Cannot generate short ideas.");
  }
  
  const prompt = `
    You are a YouTube content strategy expert specializing in creating engaging YouTube Shorts.
    A user has provided a link to a YouTube video: ${youtubeUrl}

    Based on the potential topic of this video, generate 3 distinct ideas for YouTube Shorts.
    For each Short idea, provide:
    1.  title: A catchy and concise title (max 60 characters).
    2.  description: A brief, engaging description (max 120 characters) that would compel viewers to watch.
    3.  visualConcept: A short suggestion for the key visual content or focus of the Short (e.g., "Quick demo of the final dish", "Most surprising moment", "Key takeaway explained visually").

    Return the response as a valid JSON array of objects, where each object has "title", "description", and "visualConcept" keys.
    Example format:
    [
      {
        "title": "Amazing Pasta Hack!",
        "description": "You won't believe this simple trick for perfect pasta every time. #shorts #cookinghacks",
        "visualConcept": "Show a quick before-and-after of the pasta cooking technique."
      },
      {
        "title": "Secret Pasta Ingredient",
        "description": "The one ingredient that will elevate your pasta dish. #food #pasta #shorts",
        "visualConcept": "Close-up shot of the secret ingredient being added, with dramatic reveal."
      }
    ]
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: TEXT_MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    const parsedData = JSON.parse(jsonStr) as GeminiResponseShort[];
    if (!Array.isArray(parsedData) || !parsedData.every(item => item.title && item.description && item.visualConcept)) {
        console.error("Unexpected JSON structure from Gemini API:", parsedData);
        throw new Error("Failed to parse valid shorts ideas from AI response. The format was unexpected.");
    }
    return parsedData;

  } catch (error) {
    console.error("Error generating shorts ideas with Gemini:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate shorts ideas: ${error.message}`);
    }
    throw new Error("An unknown error occurred while generating shorts ideas.");
  }
};
    