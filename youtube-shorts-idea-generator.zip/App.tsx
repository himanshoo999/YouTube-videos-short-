
import React, { useState, useCallback } from 'react';
import YouTubeInputForm from './components/YouTubeInputForm';
import ShortsDisplay from './components/ShortsDisplay';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import { generateShortsIdeas } from './services/geminiService';
import type { ShortIdea, GeminiResponseShort } from './types';
import { YouTubeIcon } from './components/icons';

const App: React.FC = () => {
  const [shorts, setShorts] = useState<ShortIdea[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentUrl, setCurrentUrl] = useState<string | null>(null);


  const handleGenerateShorts = useCallback(async (url: string) => {
    setIsLoading(true);
    setError(null);
    setShorts([]); // Clear previous shorts
    setCurrentUrl(url);

    try {
      const ideas: GeminiResponseShort[] = await generateShortsIdeas(url);
      const formattedShorts: ShortIdea[] = ideas.map((idea, index) => ({
        id: `${Date.now()}-${index}`,
        title: idea.title,
        description: idea.description,
        visualConcept: idea.visualConcept,
        thumbnailUrl: `https://picsum.photos/seed/${encodeURIComponent(idea.title)}/300/160` // Placeholder image
      }));
      setShorts(formattedShorts);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred.");
      }
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <header className="text-center mb-10">
        <div className="inline-flex items-center justify-center bg-gray-800 p-3 rounded-full shadow-lg">
            <YouTubeIcon className="h-12 w-12 text-red-500" />
        </div>
        <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 sm:text-5xl">
          AI YouTube Shorts Generator
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-gray-400 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Transform YouTube video concepts into engaging Short ideas with AI-powered titles, descriptions, and visual concepts.
        </p>
      </header>

      <main className="container mx-auto max-w-5xl">
        <YouTubeInputForm onSubmit={handleGenerateShorts} isLoading={isLoading} />
        
        {isLoading && (
          <div className="mt-12 flex justify-center">
            <LoadingSpinner />
          </div>
        )}
        
        {error && (
          <div className="mt-8 max-w-xl mx-auto">
            <ErrorMessage message={error} />
          </div>
        )}

        {!isLoading && !error && shorts.length > 0 && (
            <ShortsDisplay shorts={shorts} />
        )}
        
        {!isLoading && !error && shorts.length === 0 && currentUrl && (
            <div className="mt-12 text-center text-gray-500">
                <p>No ideas were generated for this URL. Try a different one or check the console for errors if the API key is missing.</p>
            </div>
        )}
      </main>

      <footer className="text-center mt-16 py-8 border-t border-gray-700">
        <p className="text-sm text-gray-500">
          Powered by React, Tailwind CSS, and Gemini API.
        </p>
         <p className="text-xs text-gray-600 mt-1">
          Note: This tool generates conceptual ideas for shorts and does not process or download video content.
        </p>
      </footer>
    </div>
  );
};

export default App;
    