
export interface ShortIdea {
  id: string;
  title: string;
  description: string;
  visualConcept: string;
  thumbnailUrl: string;
}

export interface GeminiResponseShort {
  title: string;
  description: string;
  visualConcept: string;
}
    